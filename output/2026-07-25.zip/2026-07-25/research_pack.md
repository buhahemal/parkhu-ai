# Parkhu research pack — 2026-07-25

- **session_date:** 2026-07-24 (trading day: False)
- **generated_at_ist:** 2026-07-26T15:48:12.503903+05:30
- **kb:** KB v1.0 (2026-06-21) | capital: 100000.0

## Regime

- market_regime: **Bearish**
- nifty: Bearish (-0.53%)
- india_vix: 13.48 (Low)
- fii_net: -3892.77 | dii_net: 5453.55
- overall_risk: Medium | global_risk: Neutral

## Funnel

- universe: 363
- trend = Bullish: 176
- price > SMA200: 148
- price > EMA50: 143
- ADX14 > 25: 80
- RSI14 in 40-80: 79
- RS > 0 vs NIFTY and sector: 64
- delivery% >= 40: 43
- no earnings within 21d: 16
- event_risk_score <= 1: 14
- TV rating not Sell: 14

## Ideas

### LODHA — Buy (score 85.9)
- Lodha Developers Ltd. | risk_sector: Real Estate
- entry 1144.1 | stop 1061.79 | t1 1308.72 | t2 1391.03 | t3 1473.34 | R:R 2.0
- qty 8 | deployed 9153.0 (9.15%) | risk ₹658.0

### ICICIBANK — Buy (score 83.7)
- ICICI Bank Limited | risk_sector: Banks
- entry 1432.9 | stop 1381.32 | t1 1536.05 | t2 1587.63 | t3 1639.2 | R:R 2.0
- qty 6 | deployed 8597.0 (8.6%) | risk ₹309.0

### IIFL — Buy (score 81.7)
- IIFL Finance Limited | risk_sector: NBFC & Capital Markets
- entry 556.55 | stop 515.37 | t1 638.9 | t2 680.08 | t3 721.25 | R:R 2.0
- qty 17 | deployed 9461.0 (9.46%) | risk ₹700.0

## Open ledger

- **ICICIBANK** status=open entry=1470.8 last=1432.9 mfe=0.0 mae=-2.85 opened=2026-07-21
- **IPCALAB** status=open entry=1828.2 last=1762.7 mfe=0.0 mae=-3.58 opened=2026-07-21
- **J&KBANK** status=open entry=184.33 last=179.01 mfe=0.6 mae=-2.89 opened=2026-07-21
- **ZYDUSLIFE** status=open entry=1146.2 last=1108.7 mfe=0.0 mae=-3.27 opened=2026-07-21
- **IIFL** status=open entry=556.55 last=556.55 mfe=0.0 mae=0.0 opened=2026-07-25
- **LODHA** status=open entry=1144.1 last=1144.1 mfe=0.0 mae=0.0 opened=2026-07-25

## Needs action

- **J&KBANK**: NO DATA — dropped out of today's universe — last seen ₹179.01 on 2026-07-23; check the chart manually
- **ZYDUSLIFE**: EARNINGS AHEAD — results inside 21 days — KB-05 says reduce or stand aside rather than hold through the print

## Swing candidates (top)

- CREDITACC: score=14 rs_nifty=10.95 deliv=55.56
- ADANIENSOL: score=13 rs_nifty=14.62 deliv=33.21
- NESTLEIND: score=13 rs_nifty=4.61 deliv=56.32
- SHYAMMETL: score=13 rs_nifty=7.11 deliv=48.32
- ATHERENERG: score=13 rs_nifty=20.85 deliv=47.89
- LAURUSLABS: score=12 rs_nifty=8.96 deliv=31.4
- ANANDRATHI: score=12 rs_nifty=7.64 deliv=53.24
- NYKAA: score=12 rs_nifty=6.9 deliv=47.2
- MOTHERSON: score=12 rs_nifty=2.84 deliv=40.07
- GODREJIND: score=12 rs_nifty=17.92 deliv=40.89
- IPCALAB: score=12 rs_nifty=10.21 deliv=42.98
- INDHOTEL: score=12 rs_nifty=1.54 deliv=48.53
- KARURVYSYA: score=12 rs_nifty=16.92 deliv=54.27
- IDFCFIRSTB: score=12 rs_nifty=4.08 deliv=48.26
- PFOCUS: score=12 rs_nifty=38.95 deliv=36.72

## World markets (India cues)

### Asia
- Nikkei: -2.73% (bear)
- Hang Seng: -0.98% (bear)
- Shanghai: -1.61% (bear)
- Kospi: -5.72% (bear)
- Taiwan: -2.67% (bear)
- ASX 200: -0.75% (bear)

### Europe
- FTSE 100: +0.91% (bull)
- DAX: +1.36% (bull)
- Euro Stoxx 50: +1.14% (bull)

### US
- S&P 500: +0.05% (neutral)
- Nasdaq: -0.64% (bear)
- Dow: +0.46% (bull)
- US VIX: -0.64% (bull)

### Macro
- USDINR: -0.33% (neutral)
- Crude WTI: -3.12% (bear)
- Brent: -3.88% (bear)
- DXY: +0.04% (neutral)
- US 10Y: -0.51% (bull)
- India ETF: +0.82% (bull)
- EM ETF: -1.97% (bear)


## Groq desk note

- **model:** llama-3.3-70b-versatile
- **stance:** defensive

The Indian market remains in a bearish regime with a low India VIX. The Nifty trend is bearish with a -0.53% change. FII net is negative while DII net is positive. Overall risk is medium.

- **LODHA** [consider_entry/high] entry=1144.1 stop=1061.79 t1=1308.72 hold=16d — Strong Parkhu score of 85.9 and a buy band
- **ICICIBANK** [manage_open/medium] entry=1432.9 stop=1381.32 t1=1536.05 hold=16d — Existing open position with a buy band and a Parkhu score of 83.7
- **IIFL** [consider_entry/medium] entry=556.55 stop=515.37 t1=638.9 hold=16d — Buy band and a Parkhu score of 81.7

### AI stock reviews

- **LODHA** [high] The LODHA setup fits a ≤1-month swing due to its recent bullish trend and strong momentum indicators, such as a high ADX and a relatively low RSI. The stock has also outperformed Nifty and its sector in the last month, indicating strong relative strength. With a high Parkhu score of 85.9, this setup has a high probability of reaching its target in the given timeframe.
  - catalysts: Earnings momentum, Sector outperformance, Bullish trend
  - risks: Market downturn, Sector rotation, Earnings disappointment
  - watch: Triggers for this setup include a breakout above the current price level, while invalidation cues include a drop below the stop level. A close eye should be kept on the overall market regime and sector performance.
- **ICICIBANK** [high] ICICIBANK's recent price action and technical indicators suggest a bullish trend, with a high Parkhu score of 83.7 and a bullish trend label. The stock's RSI and ADX values indicate a potential for further upside, and its recent outperformance of the Nifty and its sector adds to the bullish case. Given the overall bearish market regime, this setup could be a relatively safer bet for a ≤1-month swing. The stock is also close to its 52-week high, which could act as a catalyst for a breakout.
  - catalysts: Earnings anticipation, Sector outperformance, Breakout from 52-week high
  - risks: Overall bearish market regime, Interest rate changes, Sector-wide downturn
  - watch: Triggers for this trade include a strong breakout above the recent highs, while invalidation cues would be a breach of the stop level at 1381.32, indicating a failure of the bullish thesis.
- **IIFL** [high] IIFL Finance Limited is a suitable candidate for a ≤1-month swing due to its recent bullish trend and relatively high return over the past month. The stock's RSI and ADX levels indicate a potential for further upward movement. Additionally, the company's risk sector, NBFC & Capital Markets, has shown resilience in the current market regime. The overall risk is medium, but the parkhu score of 81.7 suggests a favorable setup.
  - catalysts: Bullish trend, High return over 1m, Favorable risk sector
  - risks: Medium overall risk, Bearish market regime, India VIX volatility
  - watch: Triggers for this setup include a strong breakout above the current level, while invalidation cues would be a drop below the stop level, indicating a reversal in the trend. The stock's price movement in relation to its 52-week high and the overall market regime will also be closely monitored.

### Claude feed

Bearish regime, defensive stance. Top ideas: LODHA, ICICIBANK, IIFL. Caveats: provisional scores, missing promoter pledge data, and no trade outcome history.


## Market news (AI top impact)

1. **[high]** Bearish market regime continues with India VIX at 13.48 — The current bearish market regime and high India VIX indicate increased market volatility and risk, which may impact investor sentiment and market performance.
2. **[high]** FII net outflow of -3892.77 — The significant FII net outflow may lead to a decrease in market liquidity and put downward pressure on stock prices, affecting the overall market sentiment.
3. **[medium]** SIGACHI postpones earnings call (SIGACHI) — The postponement of the earnings call may lead to uncertainty and speculation among investors, potentially impacting the stock price and market sentiment.
4. **[medium]** VOGL updates under Regulation 30 of SEBI Listing Regulations (VOGL) — The update may have a significant impact on the company's stock price and market sentiment, depending on the nature of the information disclosed.
5. **[low]** UFO Moviez India Limited updates on annual report (UFO) — The update is a routine disclosure and may not have a significant impact on the company's stock price or market sentiment.

## Deep-dive URLs (after push)

- `stock_analysis.csv`: https://raw.githubusercontent.com/buhahemal/parkhu-ai/main/output/latest/stock_analysis.csv
- `manifest.json`: https://raw.githubusercontent.com/buhahemal/parkhu-ai/main/output/latest/manifest.json
- `report.json`: https://raw.githubusercontent.com/buhahemal/parkhu-ai/main/output/latest/report.json
- `swing_brief.json`: https://raw.githubusercontent.com/buhahemal/parkhu-ai/main/output/latest/swing_brief.json
- `swing_brief.md`: https://raw.githubusercontent.com/buhahemal/parkhu-ai/main/output/latest/swing_brief.md
- `market_summary.csv`: https://raw.githubusercontent.com/buhahemal/parkhu-ai/main/output/latest/market_summary.csv

- index: https://raw.githubusercontent.com/buhahemal/parkhu-ai/main/output/index.json
- pack json: https://raw.githubusercontent.com/buhahemal/parkhu-ai/main/output/2026-07-25/research_pack.json

Start with this pack. Use urls.deep_dive for symbol-level CSVs. Prefer output/latest/ stable paths after the run is pushed. Do not require latest.zip. Capital / deployment sizing is for Claude; the Pages desk is process and market visibility only.
